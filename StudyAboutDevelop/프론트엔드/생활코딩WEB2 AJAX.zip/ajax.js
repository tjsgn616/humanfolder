function callbackMe(response){
    if(response.status == '404'){
        alert("해당 파일이 없습니다.");
    }else{
        response.text().then(function(text){
            document.querySelector('article').innerHTML = text;
        })
    }
}
